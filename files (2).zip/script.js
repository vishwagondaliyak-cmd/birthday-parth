(() => {
'use strict';
/* Paste a direct https audio URL (mp3/ogg/m4a stream). Leave as-is and everything else still works. */
const MUSIC_URL = "PASTE_DIRECT_AUDIO_URL_HERE";

const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const B = document.body, wait = ms => new Promise(r => setTimeout(r, ms));
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
scrollTo(0, 0);

/* toast + confetti */
let tt;
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('on'), 3400); }
const cv = $('#fx'), cx = cv.getContext('2d'); let P = [], run = false;
const size = () => { cv.width = innerWidth; cv.height = innerHeight; };
size(); addEventListener('resize', size);
const COL = ['#c9a0a0', '#e3cfae', '#f0c9b0', '#8f6f7a', '#f6f0e6'];
function confetti(n = 140) {
  if (reduce) n = 25;
  for (let i = 0; i < n; i++) P.push({ x: innerWidth / 2 + (Math.random() - .5) * 240, y: innerHeight * .6, vx: (Math.random() - .5) * 14, vy: -Math.random() * 16 - 4, w: 4 + Math.random() * 6, h: 8 + Math.random() * 8, r: Math.random() * 6, vr: (Math.random() - .5) * .3, c: COL[Math.random() * 5 | 0], a: 1 });
  if (!run) { run = true; requestAnimationFrame(tick); }
}
function tick() {
  cx.clearRect(0, 0, cv.width, cv.height);
  P = P.filter(p => p.a > .02 && p.y < innerHeight + 40);
  P.forEach(p => { p.vy += .35; p.vx *= .99; p.x += p.vx; p.y += p.vy; p.r += p.vr; p.a -= .004; cx.save(); cx.globalAlpha = p.a; cx.translate(p.x, p.y); cx.rotate(p.r); cx.fillStyle = p.c; cx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); cx.restore(); });
  if (P.length) requestAnimationFrame(tick); else { run = false; cx.clearRect(0, 0, cv.width, cv.height); }
}

/* cursor glow */
if (matchMedia('(pointer:fine)').matches) {
  const g = $('#glow');
  addEventListener('pointermove', e => { g.style.transform = `translate(${e.clientX}px,${e.clientY}px)`; g.style.opacity = 1; });
}

/* cover -> gate */
$('#openBtn').onclick = async () => {
  const c = $('#cover'); c.classList.add('zoom');
  await wait(reduce ? 50 : 1100);
  c.hidden = true;
  const g = $('#gate'); g.hidden = false; nextQ(); void g.offsetWidth; g.classList.add('in');
};

/* gate quiz */
const Q = [
  { t: 'Your most obvious skill?', k: ['irritat', 'annoy'], h: 'Hint: he does it professionally.' },
  { t: 'Your natural habitat?', k: ['chaos', 'chaotic'], h: 'Hint: the mood switch knows.' },
  { t: 'Your greatest contribution to my life?', k: ['annoy', 'irritat'], h: 'Hint: he does it daily.' }
];
const BAD = ['That answer has been rejected by the Parth Department.', 'Interesting. Completely wrong. Try again.', 'Bro, you ARE Parth. How did you get this wrong?', 'Denied. Have you met yourself?', 'Not even close. Think about who you are.'];
let qi = 0, lastBad = -1, wrongs = 0, busy = false;
function nextQ() {
  $('#qn').textContent = `0${qi + 1} / 03`; $('#qt').textContent = Q[qi].t;
  $('#qa').value = ''; $('#qf').textContent = ''; wrongs = 0; busy = false;
  if (matchMedia('(pointer:fine)').matches) $('#qa').focus({ preventScroll: true });
}
$('#q').onsubmit = async e => {
  e.preventDefault(); if (busy) return;
  const v = $('#qa').value.toLowerCase(), f = $('#qf');
  if (Q[qi].k.some(k => v.includes(k))) {
    busy = true; qi++;
    if (qi < Q.length) { f.textContent = 'Accepted.'; await wait(700); nextQ(); } else unlock();
  } else {
    let i; do i = Math.random() * BAD.length | 0; while (i === lastBad);
    lastBad = i; wrongs++;
    f.textContent = BAD[i] + (wrongs >= 3 ? ' ' + Q[qi].h : '');
    $('#q').classList.remove('shake'); void $('#q').offsetWidth; $('#q').classList.add('shake');
  }
};
async function unlock() {
  $('#q').hidden = true; $('#ok').hidden = false; void $('#ok').offsetWidth;
  $$('#ok .rv').forEach(e => e.classList.add('on'));
  await wait(3600);
  $('#gate').classList.remove('in'); await wait(reduce ? 50 : 1000);
  $('#gate').hidden = true;
  const r = $('#reveal'); r.hidden = false; void r.offsetWidth; r.classList.add('in');
  $$('#reveal .rv').forEach(e => e.classList.add('on'));
  $('#mp').hidden = false; $('#mood').hidden = false;
  setTimeout(() => confetti(160), reduce ? 0 : 2800);
}
$('#goBtn').onclick = () => {
  $('#main').hidden = false; B.classList.remove('lock');
  $('#story').scrollIntoView({ behavior: reduce ? 'auto' : 'smooth' });
};

/* scroll reveal */
const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('on'); io.unobserve(e.target); } }), { threshold: .2, rootMargin: '0px 0px -6% 0px' });
$$('#main .rv').forEach(e => io.observe(e));

/* archive */
const sheet = $('#sheet'); let tok = 0;
$$('.file').forEach(b => b.onclick = () => openF(b.dataset.f));
function openF(n) {
  tok++;
  $$('#sheet article').forEach(a => a.hidden = a.id !== 'f' + n);
  sheet.hidden = false; B.classList.add('lock'); void sheet.offsetWidth; sheet.classList.add('in');
  ({ 1: f1, 2: f2, 3() {}, 4() {} })[n]();
  $('#sx').focus({ preventScroll: true });
}
function closeF() { tok++; sheet.classList.remove('in'); setTimeout(() => { if (!sheet.classList.contains('in')) sheet.hidden = true; }, 500); B.classList.remove('lock'); }
$('#sx').onclick = closeF;
sheet.addEventListener('click', e => { if (e.target === sheet) closeF(); });

function f1() {
  const my = tok;
  $$('#f1 .m').forEach((m, i) => {
    const v = m.dataset.v, b = m.querySelector('b'), u = m.querySelector('u');
    u.style.width = '0'; b.textContent = '0%';
    setTimeout(() => {
      if (my !== tok) return;
      if (isNaN(v)) { b.textContent = v; u.style.width = '6%'; return; }
      u.style.width = v + '%';
      const t0 = performance.now(), to = +v;
      (function f(t) { const p = Math.min((t - t0) / 1300, 1); b.textContent = (p < 1 ? (to * p).toFixed(1) : to) + '%'; if (p < 1 && my === tok) requestAnimationFrame(f); })(t0);
    }, 350 + i * 250);
  });
}
async function f2() {
  const my = tok, els = $$('#f2 .s');
  els.forEach(e => e.classList.remove('on'));
  const L = els.filter(e => e.tagName === 'LI');
  for (const l of L) { await wait(850); if (my !== tok) return; l.classList.add('on'); }
  const rest = els.filter(e => e.tagName !== 'LI');
  await wait(1000); if (my !== tok) return; rest[0].classList.add('on'); rest[1].classList.add('on');
  await wait(2200); if (my !== tok) return; rest[2].classList.add('on');
}

const M = [
  'Remember when a completely normal conversation somehow became chaos?',
  'Somehow the stupidest conversations became the funniest memories.',
  'College would have been quieter without you. Probably better for my patience too.',
  'A suspicious amount of our friendship is just random nonsense.',
  'Some people become memories. Some people become permanent chaos.',
  'You have a rare talent for showing up at the worst possible moment. Somehow it is still fun.',
  'Half of my best stories start with "So Parth said something."',
  'We have argued about things that did not deserve a single second of debate.',
  'The day was going to be boring. Then you joined the conversation.',
  'There was a plan once. Then you had an opinion.',
  'An unreasonable number of my laughs are your fault.',
  '"Five minutes" with you has never once been five minutes.',
  'Ordinary college days turn into episodes when you are around.',
  'Peaceful is overrated anyway. You proved that.',
  'Somewhere between 1st year and now, the nonsense became a tradition.',
  'Every random moment with you is annoyingly easy to remember.'
];
let lm = -1;
$('#mg').onclick = () => {
  let i; do i = Math.random() * M.length | 0; while (i === lm);
  lm = i; const c = $('#mc'); c.classList.remove('pop'); void c.offsetWidth;
  $('#mt').textContent = M[i]; c.classList.add('pop'); $('#mg').textContent = 'Generate another';
};

$('#yes').onclick = () => { $('#cr').textContent = 'Interesting answer. Wrong, but interesting.'; $('#yes').classList.toggle('dodge'); };
$('#no').onclick = async () => {
  $('#cr').textContent = 'Correct. You may continue.';
  await wait(1500);
  $('#lockbox').hidden = true; $('#rev').hidden = false; void $('#rev').offsetWidth;
  const s = $$('#rev .s'); s[0].classList.add('on'); await wait(1600); s[1].classList.add('on');
};

/* mini question */
$$('.opt').forEach(o => o.onclick = () => {
  $$('.opt').forEach(x => x.classList.remove('picked')); o.classList.add('picked');
  $('#qres').hidden = false; confetti(30);
});

/* gift */
$('#giftBtn').onclick = async () => {
  $('#giftBox').classList.add('open'); B.classList.add('gifted'); $('#giftBtn').hidden = true;
  confetti(220); $('#mp').classList.add('pulse');
  $('#final').hidden = false; $('#end').hidden = false;
  await wait(1500);
  $('#final').scrollIntoView({ behavior: reduce ? 'auto' : 'smooth' });
};
$('#again').onclick = () => { scrollTo(0, 0); location.reload(); };

/* mood */
$('#mood').onclick = async () => {
  const v = $('#veil'); v.classList.add('on'); await wait(reduce ? 0 : 500);
  B.classList.toggle('chaos'); $('#ml').textContent = B.classList.contains('chaos') ? 'chaos' : 'soft';
  v.classList.remove('on');
};

/* secrets */
let sc = 0;
$$('.secret').forEach(s => {
  const hit = () => { if (++sc === 5) { sc = 0; toast("You found something that wasn't supposed to be here."); setTimeout(() => toast('Okay fine. Happy Birthday again. 😂'), 3600); } };
  s.onclick = hit; s.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); hit(); } };
});
const KS = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a']; let ki = 0;
addEventListener('keydown', e => {
  if (e.key === 'Escape' && !sheet.hidden) return closeF();
  const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  ki = k === KS[ki] ? ki + 1 : (k === KS[0] ? 1 : 0);
  if (ki === KS.length) { ki = 0; toast('Konami code? In this economy? Fine. You are still irritating.'); confetti(80); }
});

/* music (fully optional) */
const has = /^https:\/\/\S+$/i.test(MUSIC_URL); let au = null, ok = has;
const mp = $('#mp'), pp = $('#pp'), mn = $('#mn');
mn.textContent = has ? '' : 'No soundtrack set yet.';
$('#mpb').onclick = () => { const o = $('#mpc').hidden; $('#mpc').hidden = !o; $('#mpb').setAttribute('aria-expanded', o); };
function fail() { ok = false; mp.classList.remove('playing'); pp.textContent = 'Play'; mn.textContent = 'Soundtrack unavailable right now.'; }
pp.onclick = () => {
  if (!ok) { mn.textContent = has ? 'Soundtrack unavailable right now.' : 'No soundtrack set yet.'; return; }
  try {
    if (!au) {
      au = new Audio(); au.loop = true; au.preload = 'none'; au.volume = +$('#vol').value;
      au.addEventListener('error', fail);
      au.addEventListener('timeupdate', () => { if (au.duration) $('#pr').value = au.currentTime / au.duration * 100; });
      au.src = MUSIC_URL;
    }
    if (au.paused) { const p = au.play(); if (p) p.then(() => { mp.classList.add('playing'); pp.textContent = 'Pause'; }).catch(fail); }
    else { au.pause(); mp.classList.remove('playing'); pp.textContent = 'Play'; }
  } catch (e) { fail(); }
};
$('#pr').oninput = () => { if (au && au.duration) au.currentTime = $('#pr').value / 100 * au.duration; };
$('#vol').oninput = () => { if (au) au.volume = +$('#vol').value; };
})();
